import json
from collections import defaultdict

def count_ids(txt_file, output_questions, output_knowledge_points):
    
    questions = defaultdict(int)
    knowledge_points = defaultdict(int)

    with open(txt_file, 'r', encoding='utf-8') as file:
        while True:
            num_line = file.readline()
            if not num_line: 
                
                break 
            num = int(num_line.strip())
            
            question_line = file.readline()
            for q_id in question_line.strip().split(','):
                questions[q_id] += 1

            knowledge_line = file.readline()
            for k_id in knowledge_line.strip().split(','):
                knowledge_points[k_id] += 1

            
            _ = file.readline()

    
    sorted_questions = [{'id': q_id, 'count': count} for q_id, count in sorted(questions.items(), key=lambda item: item[1], reverse=True)]
    sorted_knowledge_points = [{'id': k_id, 'count': count} for k_id, count in sorted(knowledge_points.items(), key=lambda item: item[1], reverse=True)]

    
    with open(output_questions, 'w', encoding='utf-8') as file:
        json.dump(sorted_questions, file, ensure_ascii=False)
    with open(output_knowledge_points, 'w', encoding='utf-8') as file:
        json.dump(sorted_knowledge_points, file, ensure_ascii=False)


count_ids('train.txt', 'questions.json', 'knowledge_points.json')

